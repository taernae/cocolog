require 'test_helper'

class ContactHelperTest < ActionView::TestCase
end
