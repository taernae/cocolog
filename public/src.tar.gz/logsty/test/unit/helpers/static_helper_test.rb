require 'test_helper'

class StaticHelperTest < ActionView::TestCase
end
