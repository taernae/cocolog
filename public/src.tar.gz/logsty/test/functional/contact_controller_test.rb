require 'test_helper'

class ContactControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
