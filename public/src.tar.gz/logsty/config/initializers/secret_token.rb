# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hogger::Application.config.secret_token = 'c175b36c25fcc2d22cf60fa5c02e1615a6613ff46556094c7cc904359b232fedf4a797d23b2368cc948d921d09da302c6276d77898350e26a59bd95050914e18'
